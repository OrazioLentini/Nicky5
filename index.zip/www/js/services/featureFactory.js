angular.module('starter.services')

    .factory('MyService',function(){
  		  return { feature:""};
	})

